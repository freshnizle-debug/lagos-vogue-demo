# Shalom House Fellowship — Bible Quest

A mobile-first React/Vite Bible learning game.

## Core features

- 4 difficulty levels
- 6 Bible journey episodes per level
- Question engine designed for up to 400 questions per episode
- Scripture reference, hint and explanation on every question
- Trivia, Scripture Challenge, Who Am I?, Scramble and Scripture Detective formats
- XP, levels, streaks, gems and hearts
- Hints
- Badges and episode completion rewards
- Daily Quest
- Journey map and progress tracking
- Local fellowship leaderboard
- Local admin dashboard
- Export player data
- No-repeat question selection during a player's journey
- Responsive/mobile-first interface
- Unit tests for core game logic

## Important content note

This release contains a curated starter bank so the application is immediately playable. The data model supports hundreds of questions per episode without changing the game engine. Before publishing a large question bank, validate every question, answer, Scripture reference and translation against your chosen Bible edition.

## Run

```bash
npm install
npm run dev
```

Production build:

```bash
npm run build
```

The production output is in `dist/`.

## Admin

The prototype admin PIN is `2468`. Change it before any public deployment.

This admin is intentionally local/prototype-only. A real multi-user production system should move authentication and player data to a backend/database.
