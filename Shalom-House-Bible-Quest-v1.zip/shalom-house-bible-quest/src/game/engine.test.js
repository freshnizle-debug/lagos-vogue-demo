import { describe, expect, it } from "vitest";
import { buildSessionQuestions, calculateReward, levelFromXp, scrambleWord } from "./engine";

const questions = [
  { id: "1", difficulty: "beginner", episode: 1, answer: "God" },
  { id: "2", difficulty: "beginner", episode: 1, answer: "Adam" },
  { id: "3", difficulty: "beginner", episode: 1, answer: "Light" },
];

describe("Bible Quest engine", () => {
  it("selects questions from the requested episode and difficulty", () => {
    const result = buildSessionQuestions(questions, "beginner", 1, [], 2);
    expect(result).toHaveLength(2);
    expect(result.every(q => q.difficulty === "beginner" && q.episode === 1)).toBe(true);
  });

  it("avoids previously answered questions when enough unseen questions exist", () => {
    const result = buildSessionQuestions(questions, "beginner", 1, ["1"], 2);
    expect(result.map(q => q.id)).not.toContain("1");
  });

  it("gives zero points for a wrong answer", () => {
    expect(calculateReward({ correct: false })).toEqual({ points: 0, gems: 0, xp: 2, speedBonus: 0 });
  });

  it("gives a higher reward for harder difficulty", () => {
    const easy = calculateReward({ correct: true, basePoints: 10, difficulty: "beginner" });
    const master = calculateReward({ correct: true, basePoints: 10, difficulty: "master" });
    expect(master.points).toBeGreaterThan(easy.points);
  });

  it("maps XP to levels", () => {
    expect(levelFromXp(0)).toBe(1);
    expect(levelFromXp(99)).toBe(1);
    expect(levelFromXp(100)).toBe(2);
  });

  it("scrambles a word without changing its letters", () => {
    const word = "Bethlehem";
    const scrambled = scrambleWord(word);
    expect(scrambled.split("").sort().join("")).toBe(word.split("").sort().join(""));
  });
});