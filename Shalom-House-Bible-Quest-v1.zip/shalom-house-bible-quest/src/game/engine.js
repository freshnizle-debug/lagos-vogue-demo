import { DIFFICULTIES, EPISODES, MAX_QUESTIONS_PER_EPISODE } from "../data/journey";

export function shuffle(items) {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

export function scrambleWord(word) {
  const chars = word.split("");
  let out = word;
  for (let tries = 0; tries < 10 && out.toLowerCase() === word.toLowerCase(); tries++) {
    out = shuffle(chars).join("");
  }
  return out;
}

export function getQuestionPool(questions, difficulty, episode) {
  return questions.filter(q => q.difficulty === difficulty && q.episode === episode);
}

export function buildSessionQuestions(questions, difficulty, episode, answeredIds = [], count = 10) {
  const pool = getQuestionPool(questions, difficulty, episode);
  const unseen = pool.filter(q => !answeredIds.includes(q.id));
  const source = unseen.length >= count ? unseen : pool;
  return shuffle(source).slice(0, Math.min(count, source.length));
}

export function calculateReward({ correct, basePoints = 10, streak = 0, elapsedSeconds = 0, difficulty = "beginner", hintUsed = false }) {
  if (!correct) return { points: 0, gems: 0, xp: 2, speedBonus: 0 };
  const multiplier = { beginner: 1, intermediate: 1.2, advanced: 1.5, master: 2 }[difficulty] || 1;
  const streakBonus = Math.min(streak * 2, 20);
  const speedBonus = elapsedSeconds <= 8 ? 5 : elapsedSeconds <= 15 ? 2 : 0;
  const hintPenalty = hintUsed ? 3 : 0;
  const points = Math.max(5, Math.round((basePoints + streakBonus + speedBonus - hintPenalty) * multiplier));
  return { points, gems: hintUsed ? 2 : 3, xp: points, speedBonus };
}

export function levelFromXp(xp) {
  return Math.max(1, Math.floor(xp / 100) + 1);
}

export function episodeProgress(profile, difficulty, episode, poolSize) {
  const answered = profile.progress?.[difficulty]?.[episode] || [];
  const target = Math.min(MAX_QUESTIONS_PER_EPISODE, Math.max(poolSize, 1));
  return Math.min(100, Math.round((answered.length / target) * 100));
}

export function isDifficultyUnlocked(profile, difficulty) {
  const index = DIFFICULTIES.findIndex(d => d.id === difficulty);
  if (index <= 0) return true;
  const previous = DIFFICULTIES[index - 1].id;
  return EPISODES.every(ep => (profile.progress?.[previous]?.[ep.id] || []).length > 0);
}

export function isEpisodeUnlocked(profile, difficulty, episode) {
  if (episode === 1) return true;
  const previous = profile.episodeCompletions?.[difficulty]?.[episode - 1];
  return Boolean(previous);
}

export function todayKey() {
  return new Date().toISOString().slice(0, 10);
}