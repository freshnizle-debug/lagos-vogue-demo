export const BADGES = [
  { id: "first-step", name: "First Step", icon: "👣", text: "Answer your first question correctly." },
  { id: "streak-5", name: "On Fire", icon: "🔥", text: "Reach a 5-question streak." },
  { id: "century", name: "Century", icon: "💯", text: "Earn 100 XP." },
  { id: "episode", name: "Journey Maker", icon: "🗺️", text: "Complete an episode." },
  { id: "daily", name: "Daily Faithful", icon: "🌅", text: "Complete a Daily Quest." },
  { id: "master", name: "Quest Master", icon: "👑", text: "Reach Master difficulty." }
];

export function awardBadges(profile, { correct = false, episodeComplete = false, dailyComplete = false, difficulty = "" }) {
  const earned = new Set(profile.badges || []);
  if (correct && profile.correct === 1) earned.add("first-step");
  if (profile.bestStreak >= 5) earned.add("streak-5");
  if (profile.xp >= 100) earned.add("century");
  if (episodeComplete) earned.add("episode");
  if (dailyComplete) earned.add("daily");
  if (difficulty === "master") earned.add("master");
  return [...earned];
}