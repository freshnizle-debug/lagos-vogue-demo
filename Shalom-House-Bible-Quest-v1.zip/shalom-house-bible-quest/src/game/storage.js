const KEY = "shbf-bible-quest:v1";

export const defaultProfile = (name) => ({
  id: `${name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${Date.now()}`,
  name,
  xp: 0,
  gems: 25,
  hearts: 3,
  streak: 0,
  bestStreak: 0,
  correct: 0,
  answered: 0,
  badges: [],
  progress: {
    beginner: { 1: [], 2: [], 3: [], 4: [], 5: [], 6: [] },
    intermediate: { 1: [], 2: [], 3: [], 4: [], 5: [], 6: [] },
    advanced: { 1: [], 2: [], 3: [], 4: [], 5: [], 6: [] },
    master: { 1: [], 2: [], 3: [], 4: [], 5: [], 6: [] }
  },
  episodeCompletions: {
    beginner: {}, intermediate: {}, advanced: {}, master: {}
  },
  daily: { date: "", count: 0, rewardClaimed: false },
  sessions: [],
  createdAt: Date.now(),
  updatedAt: Date.now()
});

export function loadState() {
  try {
    return JSON.parse(localStorage.getItem(KEY)) || { profiles: {} };
  } catch {
    return { profiles: {} };
  }
}

export function saveState(state) {
  localStorage.setItem(KEY, JSON.stringify(state));
}

export function getProfile(name) {
  const state = loadState();
  const normalized = name.trim().toLowerCase();
  return state.profiles[normalized] || null;
}

export function saveProfile(profile) {
  const state = loadState();
  const key = profile.name.trim().toLowerCase();
  state.profiles[key] = { ...profile, updatedAt: Date.now() };
  saveState(state);
  return state.profiles[key];
}

export function allProfiles() {
  return Object.values(loadState().profiles);
}

export function exportState() {
  return JSON.stringify(loadState(), null, 2);
}