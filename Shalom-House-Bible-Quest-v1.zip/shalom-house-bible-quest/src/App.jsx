import React, { useMemo, useState } from "react";
import { BookOpen, Flame, Gem, Heart, Home, Lock, Map, Medal, Shield, Sparkles, Trophy, User, Zap, Lightbulb, ChevronRight, RotateCcw, Download, Settings, CheckCircle2, XCircle } from "lucide-react";
import { QUESTIONS } from "./data/questions";
import { DIFFICULTIES, EPISODES, QUESTION_TYPES, SESSION_LENGTH, STARTING_HEARTS, HINT_COST, DAILY_TARGET, MAX_QUESTIONS_PER_EPISODE } from "./data/journey";
import { shuffle, scrambleWord, buildSessionQuestions, calculateReward, levelFromXp, isDifficultyUnlocked, isEpisodeUnlocked, todayKey } from "./game/engine";
import { defaultProfile, getProfile, saveProfile, allProfiles, exportState } from "./game/storage";
import { awardBadges, BADGES } from "./game/rewards";

const ADMIN_PIN = "2468";

function App() {
  const [screen, setScreen] = useState("home");
  const [name, setName] = useState("");
  const [profile, setProfile] = useState(null);
  const [difficulty, setDifficulty] = useState("beginner");
  const [episode, setEpisode] = useState(1);
  const [session, setSession] = useState(null);
  const [notice, setNotice] = useState("");

  const startPlayer = () => {
    const clean = name.trim();
    if (!clean) return setNotice("Please enter your name first.");
    let p = getProfile(clean);
    if (!p) p = defaultProfile(clean);
    setProfile(p);
    setNotice("");
    setScreen("journey");
  };

  const startSession = (diff, ep) => {
    if (!profile) return;
    if (!isDifficultyUnlocked(profile, diff)) return setNotice("Finish the previous difficulty first.");
    if (!isEpisodeUnlocked(profile, diff, ep)) return setNotice("Complete the previous episode to unlock this one.");
    const answered = profile.progress?.[diff]?.[ep] || [];
    const qs = buildSessionQuestions(QUESTIONS, diff, ep, answered, SESSION_LENGTH);
    if (!qs.length) return setNotice("This episode needs more questions in the bank.");
    setDifficulty(diff); setEpisode(ep);
    setSession({
      questions: qs, index: 0, score: 0, streak: 0, hearts: STARTING_HEARTS,
      selected: null, submitted: false, hintUsed: false, startedAt: Date.now(), results: []
    });
    setNotice("");
    setScreen("play");
  };

  const persist = (next) => {
    const saved = saveProfile(next);
    setProfile(saved);
    return saved;
  };

  const submitAnswer = (value) => {
    if (!session || session.submitted) return;
    const q = session.questions[session.index];
    const elapsed = Math.round((Date.now() - session.startedAt) / 1000);
    const correct = String(value).trim().toLowerCase() === String(q.answer).trim().toLowerCase();
    const nextStreak = correct ? session.streak + 1 : 0;
    const reward = calculateReward({
      correct, basePoints: q.points || 10, streak: session.streak,
      elapsedSeconds: elapsed, difficulty, hintUsed: session.hintUsed
    });
    const next = {
      ...profile,
      xp: profile.xp + reward.xp,
      gems: Math.max(0, profile.gems + reward.gems),
      hearts: correct ? session.hearts : Math.max(0, session.hearts - 1),
      streak: nextStreak,
      bestStreak: Math.max(profile.bestStreak, nextStreak),
      correct: profile.correct + (correct ? 1 : 0),
      answered: profile.answered + 1,
      progress: {
        ...profile.progress,
        [difficulty]: {
          ...profile.progress[difficulty],
          [episode]: [...new Set([...(profile.progress?.[difficulty]?.[episode] || []), q.id])]
        }
      }
    };
    const newProgressCount = next.progress[difficulty][episode].length;
    const poolSize = QUESTIONS.filter(x => x.difficulty === difficulty && x.episode === episode).length;
    const episodeComplete = newProgressCount >= Math.min(MAX_QUESTIONS_PER_EPISODE, poolSize);
    if (episodeComplete) {
      next.episodeCompletions = {
        ...next.episodeCompletions,
        [difficulty]: { ...next.episodeCompletions[difficulty], [episode]: Date.now() }
      };
    }
    const daily = next.daily?.date === todayKey() ? next.daily : { date: todayKey(), count: 0, rewardClaimed: false };
    daily.count += 1;
    let dailyComplete = false;
    if (daily.count >= DAILY_TARGET && !daily.rewardClaimed) {
      daily.rewardClaimed = true;
      next.gems += 10;
      dailyComplete = true;
    }
    next.daily = daily;
    next.badges = awardBadges(next, { correct, episodeComplete, dailyComplete, difficulty });
    persist(next);
    setSession(s => ({
      ...s,
      selected: value,
      submitted: true,
      score: s.score + reward.points,
      streak: nextStreak,
      hearts: correct ? s.hearts : Math.max(0, s.hearts - 1),
      results: [...s.results, { correct, reward, q }]
    }));
  };

  const nextQuestion = () => {
    if (!session) return;
    const last = session.index >= session.questions.length - 1 || session.hearts <= 0;
    if (last) {
      setSession(null);
      setScreen("results");
      return;
    }
    setSession(s => ({ ...s, index: s.index + 1, selected: null, submitted: false, hintUsed: false, startedAt: Date.now() }));
  };

  const useHint = () => {
    if (!session || session.submitted || session.hintUsed || profile.gems < HINT_COST) return;
    persist({ ...profile, gems: profile.gems - HINT_COST });
    setSession(s => ({ ...s, hintUsed: true }));
  };

  const reset = () => {
    setProfile(null); setSession(null); setName(""); setScreen("home");
  };

  const level = profile ? levelFromXp(profile.xp) : 1;
  const dailyCount = profile?.daily?.date === todayKey() ? profile.daily.count : 0;

  return (
    <div className="app-shell">
      <header className="topbar">
        <button className="brand" onClick={() => setScreen(profile ? "journey" : "home")}>
          <span className="brand-mark">✦</span>
          <span><strong>SHALOM HOUSE</strong><small>BIBLE QUEST</small></span>
        </button>
        {profile && (
          <div className="top-stats">
            <span><Zap size={16}/> {profile.xp} XP</span>
            <span><Gem size={16}/> {profile.gems}</span>
            <span><Flame size={16}/> {profile.bestStreak}</span>
          </div>
        )}
      </header>

      {notice && <div className="notice">{notice}<button onClick={() => setNotice("")}>×</button></div>}

      {screen === "home" && <HomeScreen name={name} setName={setName} onStart={startPlayer} />}
      {screen === "journey" && profile && (
        <JourneyScreen profile={profile} difficulty={difficulty} setDifficulty={setDifficulty}
          startSession={startSession} setScreen={setScreen} dailyCount={dailyCount} />
      )}
      {screen === "play" && session && profile && (
        <PlayScreen session={session} difficulty={difficulty} episode={episode}
          onAnswer={submitAnswer} onNext={nextQuestion} onHint={useHint} gems={profile.gems} />
      )}
      {screen === "results" && profile && <ResultsScreen profile={profile} difficulty={difficulty} episode={episode} onReplay={() => startSession(difficulty, episode)} onJourney={() => setScreen("journey")} />}
      {screen === "profile" && profile && <ProfileScreen profile={profile} level={level} setScreen={setScreen} reset={reset} />}
      {screen === "leaderboard" && <LeaderboardScreen profiles={allProfiles()} setScreen={setScreen} />}
      {screen === "admin" && <AdminScreen setScreen={setScreen} />}

      {profile && screen !== "play" && (
        <nav className="bottom-nav">
          <button onClick={() => setScreen("journey")}><Map/><span>Journey</span></button>
          <button onClick={() => setScreen("leaderboard")}><Trophy/><span>Ranks</span></button>
          <button onClick={() => setScreen("profile")}><User/><span>Profile</span></button>
          <button onClick={() => setScreen("admin")}><Shield/><span>Admin</span></button>
        </nav>
      )}
    </div>
  );
}

function HomeScreen({ name, setName, onStart }) {
  return <main className="hero page">
    <div className="hero-symbol"><BookOpen size={54}/></div>
    <p className="eyebrow">PLAY • LEARN • JOURNEY THROUGH THE WORD</p>
    <h1>SHALOM HOUSE<br/><span>BIBLE QUEST</span></h1>
    <p className="hero-copy">A Bible adventure where every question takes you deeper into Scripture.</p>
    <div className="name-card">
      <label>What should we call you?</label>
      <input value={name} onChange={e => setName(e.target.value)} onKeyDown={e => e.key === "Enter" && onStart()} placeholder="Enter your name" maxLength={30}/>
      <button className="primary" onClick={onStart}>Begin My Journey <ChevronRight/></button>
    </div>
    <div className="feature-row">
      <span>📖 6 Episodes</span><span>🏆 Rewards</span><span>🔥 Streaks</span><span>💎 Gems</span>
    </div>
  </main>;
}

function JourneyScreen({ profile, difficulty, setDifficulty, startSession, setScreen, dailyCount }) {
  return <main className="page">
    <div className="page-head">
      <div><p className="eyebrow">WELCOME, {profile.name.toUpperCase()}</p><h2>Your Bible Journey</h2></div>
      <div className="daily-pill"><Sparkles size={16}/> Daily Quest {Math.min(dailyCount, DAILY_TARGET)}/{DAILY_TARGET}</div>
    </div>

    <section className="difficulty-grid">
      {DIFFICULTIES.map(d => {
        const unlocked = isDifficultyUnlocked(profile, d.id);
        return <button key={d.id} className={`difficulty ${d.id} ${difficulty === d.id ? "active" : ""} ${!unlocked ? "locked" : ""}`} onClick={() => unlocked && setDifficulty(d.id)}>
          <span className="diff-icon">{unlocked ? "✦" : <Lock size={20}/>}</span>
          <span><strong>{d.name}</strong><small>{d.subtitle}</small></span>
          {!unlocked && <em>LOCKED</em>}
        </button>
      })}
    </section>

    <section className="journey-map">
      <div className="section-title"><Map/><div><h3>{DIFFICULTIES.find(x => x.id === difficulty).name} Journey</h3><p>Six chapters. One extraordinary journey.</p></div></div>
      <div className="episode-grid">
        {EPISODES.map(ep => {
          const pool = QUESTIONS.filter(q => q.difficulty === difficulty && q.episode === ep.id).length;
          const answered = profile.progress?.[difficulty]?.[ep.id]?.length || 0;
          const unlocked = isEpisodeUnlocked(profile, difficulty, ep.id);
          const complete = profile.episodeCompletions?.[difficulty]?.[ep.id];
          const percent = pool ? Math.min(100, Math.round(answered / Math.min(pool, MAX_QUESTIONS_PER_EPISODE) * 100)) : 0;
          return <button key={ep.id} className={`episode-card ${!unlocked ? "locked" : ""} ${complete ? "complete" : ""}`} onClick={() => unlocked && startSession(difficulty, ep.id)}>
            <div className="episode-top"><span className="episode-icon">{ep.icon}</span><span className="episode-number">EP {ep.id}</span></div>
            <h4>{ep.title}</h4><p>{ep.range}</p><small>{ep.description}</small>
            <div className="progress-track"><i style={{width: `${percent}%`}}/></div>
            <div className="episode-foot"><span>{answered}/{pool || 0} answered</span>{complete ? <span>✓ COMPLETE</span> : unlocked ? <span>PLAY <ChevronRight size={14}/></span> : <Lock size={15}/>}</div>
          </button>
        })}
      </div>
    </section>

    <div className="quick-actions">
      <button onClick={() => setScreen("profile")}><User/> My Profile</button>
      <button onClick={() => setScreen("leaderboard")}><Trophy/> Fellowship Ranks</button>
    </div>
  </main>;
}

function PlayScreen({ session, difficulty, episode, onAnswer, onNext, onHint, gems }) {
  const q = session.questions[session.index];
  const typeName = QUESTION_TYPES[q.type] || "Bible Challenge";
  const options = useMemo(() => q.type === "scramble" ? null : shuffle(q.options || [q.answer, "Not sure", "Another answer", "None of these"]), [q.id]);
  const [scrambleInput, setScrambleInput] = useState("");
  const [hidden, setHidden] = useState([]);

  React.useEffect(() => { setScrambleInput(""); setHidden([]); }, [q.id]);

  const displayOptions = options?.filter(o => !hidden.includes(o));
  const scramble = scrambleWord(q.answer);
  const correct = session.submitted && String(session.selected).toLowerCase() === String(q.answer).toLowerCase();

  return <main className="page play-page">
    <div className="play-head">
      <button className="ghost" onClick={() => window.history.back()}>←</button>
      <div className="play-meta"><span>{DIFFICULTIES.find(x => x.id === difficulty)?.name}</span><span>Episode {episode}</span></div>
      <div className="hearts">{Array.from({length: STARTING_HEARTS}).map((_,i)=><Heart key={i} size={19} fill={i < session.hearts ? "currentColor" : "none"} className={i < session.hearts ? "alive" : "dead"}/>)}</div>
    </div>
    <div className="question-progress"><span>Question {session.index + 1}/{session.questions.length}</span><i><b style={{width: `${((session.index+1)/session.questions.length)*100}%`}}/></i><span>{session.score} pts</span></div>

    <section className="question-card">
      <div className="question-type"><Sparkles size={15}/> {typeName}</div>
      <h2>{q.question}</h2>
      <div className="scripture-hint"><BookOpen size={18}/><div><strong>{q.scripture.reference}</strong><p>{q.scripture.hint}</p></div></div>

      {q.type === "scramble" ? <div className="scramble-area">
        <div className="scramble-word">{scramble}</div>
        <input value={scrambleInput} onChange={e => setScrambleInput(e.target.value)} placeholder="Type the answer"/>
        {!session.submitted && <button className="primary" onClick={() => onAnswer(scrambleInput)}>Submit Answer</button>}
      </div> : <div className="options">
        {displayOptions.map(o => <button key={o} disabled={session.submitted} className={`option ${session.submitted ? (String(o).toLowerCase() === String(q.answer).toLowerCase() ? "correct" : String(o) === String(session.selected) ? "wrong" : "") : ""}`} onClick={() => onAnswer(o)}>
          <span>{o}</span>{session.submitted && String(o).toLowerCase() === String(q.answer).toLowerCase() && <CheckCircle2/>}{session.submitted && String(o) === String(session.selected) && String(o).toLowerCase() !== String(q.answer).toLowerCase() && <XCircle/>}
        </button>)}
      </div>}

      <div className="question-actions">
        {!session.submitted && <button className="hint-btn" onClick={onHint} disabled={session.hintUsed || gems < HINT_COST}><Lightbulb/> {session.hintUsed ? "Hint Used" : `Use Hint • ${HINT_COST} gems`}</button>}
        {session.submitted && <div className={`feedback ${correct ? "good" : "bad"}`}><strong>{correct ? "Correct! 🎉" : "Keep learning."}</strong><span>{correct ? `+${session.results.at(-1)?.reward?.points || 0} points` : `Answer: ${q.answer}`}</span><p>{q.explanation}</p><small>{q.scripture.reference}</small></div>}
        {session.submitted && <button className="primary next" onClick={onNext}>{session.index === session.questions.length - 1 || session.hearts <= 0 ? "See Results" : "Next Question"} <ChevronRight/></button>}
      </div>
    </section>
  </main>;
}

function ResultsScreen({ profile, difficulty, episode, onReplay, onJourney }) {
  const answered = profile.answered;
  return <main className="page results">
    <div className="result-medal">🏆</div>
    <p className="eyebrow">QUEST COMPLETE</p>
    <h1>Well done, {profile.name}!</h1>
    <p>Your journey continues. Keep growing in the Word.</p>
    <div className="result-grid">
      <div><Zap/><strong>{profile.xp}</strong><small>Total XP</small></div>
      <div><Flame/><strong>{profile.bestStreak}</strong><small>Best Streak</small></div>
      <div><Gem/><strong>{profile.gems}</strong><small>Gems</small></div>
      <div><Medal/><strong>{profile.badges.length}</strong><small>Badges</small></div>
    </div>
    <div className="result-actions"><button className="primary" onClick={onReplay}><RotateCcw/> Play Again</button><button className="secondary" onClick={onJourney}><Map/> Continue Journey</button></div>
  </main>;
}

function ProfileScreen({ profile, level, setScreen, reset }) {
  const earned = BADGES.filter(b => profile.badges.includes(b.id));
  return <main className="page">
    <div className="profile-card">
      <div className="avatar">{profile.name[0]?.toUpperCase()}</div><h2>{profile.name}</h2><p>Level {level} Bible Explorer</p>
      <div className="xpbar"><i style={{width: `${profile.xp % 100}%`}}/></div><small>{profile.xp % 100}/100 XP to next level</small>
    </div>
    <div className="stats-grid">
      <div><strong>{profile.answered}</strong><span>Questions</span></div><div><strong>{profile.correct}</strong><span>Correct</span></div><div><strong>{profile.bestStreak}</strong><span>Best Streak</span></div><div><strong>{profile.xp}</strong><span>XP</span></div>
    </div>
    <section className="panel"><div className="section-title"><Medal/><div><h3>Badges</h3><p>Your achievements</p></div></div><div className="badges">{BADGES.map(b => <div className={`badge ${profile.badges.includes(b.id) ? "earned" : ""}`} key={b.id}><span>{b.icon}</span><strong>{b.name}</strong><small>{b.text}</small></div>)}</div></section>
    <div className="quick-actions"><button onClick={() => setScreen("journey")}><Map/> Journey</button><button onClick={reset}><Home/> Switch Player</button></div>
  </main>;
}

function LeaderboardScreen({ profiles, setScreen }) {
  const ranked = [...profiles].sort((a,b) => b.xp - a.xp).slice(0, 20);
  return <main className="page">
    <div className="page-head"><div><p className="eyebrow">FELLOWSHIP</p><h2>Quest Ranks</h2></div><Trophy size={36}/></div>
    <section className="leaderboard panel">{ranked.length ? ranked.map((p,i) => <div className="rank-row" key={p.id}><b>#{i+1}</b><span className="rank-avatar">{p.name[0]}</span><strong>{p.name}</strong><span>{p.xp} XP</span></div>) : <p>No players yet on this device.</p>}</section>
    <button className="secondary" onClick={() => setScreen("journey")}>Back to Journey</button>
  </main>;
}

function AdminScreen({ setScreen }) {
  const [authed, setAuthed] = useState(false);
  const [pin, setPin] = useState("");
  const profiles = allProfiles();
  if (!authed) return <main className="page admin-gate"><Shield size={52}/><h2>Admin Dashboard</h2><p>Prototype local admin access.</p><input type="password" value={pin} onChange={e => setPin(e.target.value)} placeholder="PIN"/><button className="primary" onClick={() => pin === ADMIN_PIN ? setAuthed(true) : alert("Incorrect PIN")}>Unlock</button><button className="ghost" onClick={() => setScreen("journey")}>Back</button></main>;
  const totalAnswered = profiles.reduce((a,p) => a+p.answered,0);
  const totalCorrect = profiles.reduce((a,p) => a+p.correct,0);
  return <main className="page">
    <div className="page-head"><div><p className="eyebrow">SHALOM HOUSE</p><h2>Admin Dashboard</h2></div><button className="secondary" onClick={() => { const blob = new Blob([exportState()], {type:"application/json"}); const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download="bible-quest-data.json"; a.click(); }}><Download/> Export</button></div>
    <div className="stats-grid"><div><strong>{profiles.length}</strong><span>Players</span></div><div><strong>{totalAnswered}</strong><span>Questions</span></div><div><strong>{totalCorrect}</strong><span>Correct</span></div><div><strong>{totalAnswered ? Math.round(totalCorrect/totalAnswered*100) : 0}%</strong><span>Accuracy</span></div></div>
    <section className="panel"><div className="section-title"><Settings/><div><h3>Question Bank</h3><p>{QUESTIONS.length} curated starter questions loaded • engine supports up to 400 per episode</p></div></div><div className="admin-list">{DIFFICULTIES.map(d => <div key={d.id}><strong>{d.name}</strong><span>{EPISODES.reduce((n,e)=>n+QUESTIONS.filter(q=>q.difficulty===d.id&&q.episode===e.id).length,0)} questions</span></div>)}</div></section>
    <button className="secondary" onClick={() => setScreen("journey")}>Back to Journey</button>
  </main>;
}

export default App;
