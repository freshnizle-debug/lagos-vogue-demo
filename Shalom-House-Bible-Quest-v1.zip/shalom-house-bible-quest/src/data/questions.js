export const QUESTIONS = [
  {
    "id": "b-1",
    "difficulty": "beginner",
    "episode": 1,
    "type": "trivia",
    "question": "Who created the heavens and the earth?",
    "answer": "God",
    "options": [
      "God",
      "Moses",
      "Abraham",
      "David"
    ],
    "scripture": {
      "reference": "Genesis 1:1",
      "hint": "The Bible opens with God's act of creation."
    },
    "explanation": "Genesis begins by identifying God as Creator.",
    "points": 15
  },
  {
    "id": "b-2",
    "difficulty": "beginner",
    "episode": 1,
    "type": "trivia",
    "question": "What was the first thing God created according to Genesis 1?",
    "answer": "Light",
    "options": [
      "Light",
      "Man",
      "The sea",
      "The sun"
    ],
    "scripture": {
      "reference": "Genesis 1:3",
      "hint": "God spoke and light appeared before the lights of day four."
    },
    "explanation": "Genesis records light appearing on the first day.",
    "points": 15
  },
  {
    "id": "b-3",
    "difficulty": "beginner",
    "episode": 1,
    "type": "who",
    "question": "I was formed from the dust of the ground and received the breath of life. Who am I?",
    "answer": "Adam",
    "options": [
      "Adam",
      "Noah",
      "Isaac",
      "Jacob"
    ],
    "scripture": {
      "reference": "Genesis 2:7",
      "hint": "My name is associated with humanity and the ground."
    },
    "explanation": "Genesis describes God forming Adam from dust.",
    "points": 15
  },
  {
    "id": "b-4",
    "difficulty": "beginner",
    "episode": 2,
    "type": "trivia",
    "question": "Who was sold by his brothers and later became a ruler in Egypt?",
    "answer": "Joseph",
    "options": [
      "Joseph",
      "Benjamin",
      "Esau",
      "Samuel"
    ],
    "scripture": {
      "reference": "Genesis 37; 41",
      "hint": "His story includes a coat, dreams and Egypt."
    },
    "explanation": "Joseph's brothers sold him, but God raised him to leadership.",
    "points": 15
  },
  {
    "id": "b-5",
    "difficulty": "beginner",
    "episode": 2,
    "type": "scripture",
    "question": "Who received a coat of many colors from his father?",
    "answer": "Joseph",
    "options": [
      "Joseph",
      "Judah",
      "Benjamin",
      "Reuben"
    ],
    "scripture": {
      "reference": "Genesis 37:3",
      "hint": "The gift showed Jacob's special affection for one son."
    },
    "explanation": "Joseph received a distinctive robe from Jacob.",
    "points": 15
  },
  {
    "id": "b-6",
    "difficulty": "beginner",
    "episode": 2,
    "type": "who",
    "question": "My brothers bowed before me, just as my dreams had foretold. Who am I?",
    "answer": "Joseph",
    "options": [
      "Joseph",
      "Isaac",
      "Moses",
      "Joshua"
    ],
    "scripture": {
      "reference": "Genesis 42:6",
      "hint": "Think about the dreams Joseph had as a young man."
    },
    "explanation": "Joseph's dreams foreshadowed his family's later dependence on him.",
    "points": 15
  },
  {
    "id": "b-7",
    "difficulty": "beginner",
    "episode": 3,
    "type": "trivia",
    "question": "Who led Israel out of Egypt?",
    "answer": "Moses",
    "options": [
      "Moses",
      "Joshua",
      "Aaron",
      "David"
    ],
    "scripture": {
      "reference": "Exodus 3–14",
      "hint": "God called him from a burning bush."
    },
    "explanation": "Moses led Israel during the Exodus.",
    "points": 15
  },
  {
    "id": "b-8",
    "difficulty": "beginner",
    "episode": 3,
    "type": "trivia",
    "question": "What did God provide from heaven for Israel to eat in the wilderness?",
    "answer": "Manna",
    "options": [
      "Manna",
      "Grapes",
      "Fish",
      "Olives"
    ],
    "scripture": {
      "reference": "Exodus 16:4",
      "hint": "Its name is connected with the question, 'What is it?'"
    },
    "explanation": "Manna was God's provision for Israel in the wilderness.",
    "points": 15
  },
  {
    "id": "b-9",
    "difficulty": "beginner",
    "episode": 3,
    "type": "scripture",
    "question": "Where did Moses receive the Ten Commandments?",
    "answer": "Mount Sinai",
    "options": [
      "Mount Sinai",
      "Mount Carmel",
      "Mount Zion",
      "Mount Tabor"
    ],
    "scripture": {
      "reference": "Exodus 19–20",
      "hint": "The covenant was given after Israel left Egypt."
    },
    "explanation": "Mount Sinai was the setting for the giving of the Law.",
    "points": 15
  },
  {
    "id": "b-10",
    "difficulty": "beginner",
    "episode": 4,
    "type": "trivia",
    "question": "Who defeated Goliath?",
    "answer": "David",
    "options": [
      "David",
      "Saul",
      "Jonathan",
      "Samson"
    ],
    "scripture": {
      "reference": "1 Samuel 17",
      "hint": "He used a sling and five smooth stones."
    },
    "explanation": "David trusted God and defeated Goliath.",
    "points": 15
  },
  {
    "id": "b-11",
    "difficulty": "beginner",
    "episode": 4,
    "type": "trivia",
    "question": "Who was Israel's first king?",
    "answer": "Saul",
    "options": [
      "Saul",
      "David",
      "Solomon",
      "Samuel"
    ],
    "scripture": {
      "reference": "1 Samuel 10:1",
      "hint": "Samuel anointed him as Israel's first king."
    },
    "explanation": "Saul became Israel's first king.",
    "points": 15
  },
  {
    "id": "b-12",
    "difficulty": "beginner",
    "episode": 4,
    "type": "who",
    "question": "I was known for great strength, but my strength was tied to my Nazirite calling. Who am I?",
    "answer": "Samson",
    "options": [
      "Samson",
      "Gideon",
      "Elijah",
      "Josiah"
    ],
    "scripture": {
      "reference": "Judges 13–16",
      "hint": "Think about a man whose hair became a symbol of his consecration."
    },
    "explanation": "Samson's story is told in Judges 13–16.",
    "points": 15
  },
  {
    "id": "b-13",
    "difficulty": "beginner",
    "episode": 5,
    "type": "trivia",
    "question": "Who was thrown into a den of lions?",
    "answer": "Daniel",
    "options": [
      "Daniel",
      "Jeremiah",
      "Ezekiel",
      "Ezra"
    ],
    "scripture": {
      "reference": "Daniel 6",
      "hint": "He continued praying to God despite a royal decree."
    },
    "explanation": "Daniel was protected by God in the lions' den.",
    "points": 15
  },
  {
    "id": "b-14",
    "difficulty": "beginner",
    "episode": 5,
    "type": "trivia",
    "question": "Which prophet confronted the prophets of Baal on Mount Carmel?",
    "answer": "Elijah",
    "options": [
      "Elijah",
      "Elisha",
      "Isaiah",
      "Jeremiah"
    ],
    "scripture": {
      "reference": "1 Kings 18",
      "hint": "Fire from heaven answered his prayer."
    },
    "explanation": "Elijah challenged the prophets of Baal at Carmel.",
    "points": 15
  },
  {
    "id": "b-15",
    "difficulty": "beginner",
    "episode": 5,
    "type": "who",
    "question": "I was swallowed by a great fish after fleeing from God's command. Who am I?",
    "answer": "Jonah",
    "options": [
      "Jonah",
      "Micah",
      "Amos",
      "Nahum"
    ],
    "scripture": {
      "reference": "Jonah 1–2",
      "hint": "My story begins with a ship and a storm."
    },
    "explanation": "Jonah fled from God's instruction and was swallowed by a great fish.",
    "points": 15
  },
  {
    "id": "b-16",
    "difficulty": "beginner",
    "episode": 6,
    "type": "trivia",
    "question": "Where was Jesus born?",
    "answer": "Bethlehem",
    "options": [
      "Bethlehem",
      "Nazareth",
      "Jerusalem",
      "Capernaum"
    ],
    "scripture": {
      "reference": "Matthew 2:1",
      "hint": "Micah had prophesied about this town."
    },
    "explanation": "Jesus was born in Bethlehem of Judea.",
    "points": 15
  },
  {
    "id": "b-17",
    "difficulty": "beginner",
    "episode": 6,
    "type": "trivia",
    "question": "Who baptized Jesus?",
    "answer": "John the Baptist",
    "options": [
      "John the Baptist",
      "Peter",
      "James",
      "Philip"
    ],
    "scripture": {
      "reference": "Matthew 3:13–17",
      "hint": "He preached repentance in the wilderness."
    },
    "explanation": "John baptized Jesus in the Jordan.",
    "points": 15
  },
  {
    "id": "b-18",
    "difficulty": "beginner",
    "episode": 6,
    "type": "trivia",
    "question": "How many disciples did Jesus appoint as the Twelve?",
    "answer": "12",
    "options": [
      "10",
      "12",
      "14",
      "70"
    ],
    "scripture": {
      "reference": "Luke 6:13",
      "hint": "The number matches the tribes of Israel."
    },
    "explanation": "Jesus appointed twelve apostles.",
    "points": 15
  },
  {
    "id": "i-x1",
    "difficulty": "intermediate",
    "episode": 1,
    "type": "scripture",
    "question": "What sign did God set in the sky as a covenant after the Flood?",
    "answer": "Rainbow",
    "options": [
      "Rainbow",
      "Star",
      "Cloud",
      "Pillar of fire"
    ],
    "scripture": {
      "reference": "Genesis 9:12–16",
      "hint": "It appears after rain and became a covenant sign."
    },
    "explanation": "The rainbow signified God's covenant with Noah.",
    "points": 18
  },
  {
    "id": "i-x2",
    "difficulty": "intermediate",
    "episode": 2,
    "type": "trivia",
    "question": "Who was Jacob's youngest son?",
    "answer": "Benjamin",
    "options": [
      "Benjamin",
      "Joseph",
      "Judah",
      "Levi"
    ],
    "scripture": {
      "reference": "Genesis 35:18",
      "hint": "His mother Rachel named him near her death."
    },
    "explanation": "Benjamin was Rachel's second son and Jacob's youngest.",
    "points": 18
  },
  {
    "id": "i-x3",
    "difficulty": "intermediate",
    "episode": 3,
    "type": "scripture",
    "question": "What did the Israelites cross on dry ground during the Exodus?",
    "answer": "Red Sea",
    "options": [
      "Red Sea",
      "Jordan River",
      "Nile",
      "Dead Sea"
    ],
    "scripture": {
      "reference": "Exodus 14:21–22",
      "hint": "Moses stretched out his hand over it."
    },
    "explanation": "God made a path through the sea for Israel.",
    "points": 18
  },
  {
    "id": "i-x4",
    "difficulty": "intermediate",
    "episode": 4,
    "type": "trivia",
    "question": "Who succeeded Moses as Israel's leader?",
    "answer": "Joshua",
    "options": [
      "Joshua",
      "Caleb",
      "Aaron",
      "Samuel"
    ],
    "scripture": {
      "reference": "Joshua 1:1–2",
      "hint": "God told him to be strong and courageous."
    },
    "explanation": "Joshua led Israel after Moses.",
    "points": 18
  },
  {
    "id": "i-x5",
    "difficulty": "intermediate",
    "episode": 5,
    "type": "trivia",
    "question": "Which prophet saw a valley of dry bones?",
    "answer": "Ezekiel",
    "options": [
      "Ezekiel",
      "Isaiah",
      "Jeremiah",
      "Hosea"
    ],
    "scripture": {
      "reference": "Ezekiel 37:1–14",
      "hint": "The vision pictured restoration and life."
    },
    "explanation": "Ezekiel's vision of dry bones symbolized restoration.",
    "points": 18
  },
  {
    "id": "i-x6",
    "difficulty": "intermediate",
    "episode": 6,
    "type": "scripture",
    "question": "What did Jesus turn water into at Cana?",
    "answer": "Wine",
    "options": [
      "Wine",
      "Oil",
      "Milk",
      "Honey"
    ],
    "scripture": {
      "reference": "John 2:1–11",
      "hint": "It was His first recorded sign in John's Gospel."
    },
    "explanation": "Jesus changed water into wine at a wedding in Cana.",
    "points": 18
  },
  {
    "id": "a-x7",
    "difficulty": "advanced",
    "episode": 1,
    "type": "detective",
    "question": "I laughed when I heard I would have a son in old age. Who am I?",
    "answer": "Sarah",
    "options": [
      "Sarah",
      "Rebekah",
      "Rachel",
      "Hannah"
    ],
    "scripture": {
      "reference": "Genesis 18:10–15",
      "hint": "Her laughter gave Isaac his name's connection to joy."
    },
    "explanation": "Sarah laughed at the promise of a son and later bore Isaac.",
    "points": 22
  },
  {
    "id": "a-x8",
    "difficulty": "advanced",
    "episode": 2,
    "type": "trivia",
    "question": "Which son of Jacob interpreted Pharaoh's dreams?",
    "answer": "Joseph",
    "options": [
      "Joseph",
      "Judah",
      "Levi",
      "Benjamin"
    ],
    "scripture": {
      "reference": "Genesis 41:15–16",
      "hint": "He gave God the credit for interpretation."
    },
    "explanation": "Joseph interpreted Pharaoh's dreams by God's help.",
    "points": 22
  },
  {
    "id": "a-x9",
    "difficulty": "advanced",
    "episode": 3,
    "type": "scripture",
    "question": "What was kept inside the Ark of the Covenant according to Hebrews?",
    "answer": "The covenant tablets",
    "options": [
      "The covenant tablets",
      "David's sword",
      "Aaron's crown",
      "A scroll of Psalms"
    ],
    "scripture": {
      "reference": "Hebrews 9:4",
      "hint": "Hebrews lists this item among the contents of the ark."
    },
    "explanation": "Hebrews 9:4 mentions the golden pot, Aaron's rod and the covenant tablets.",
    "points": 22
  },
  {
    "id": "a-x10",
    "difficulty": "advanced",
    "episode": 4,
    "type": "trivia",
    "question": "Which king asked God for wisdom rather than riches?",
    "answer": "Solomon",
    "options": [
      "Solomon",
      "David",
      "Hezekiah",
      "Josiah"
    ],
    "scripture": {
      "reference": "1 Kings 3:5–12",
      "hint": "God appeared to him in a dream at Gibeon."
    },
    "explanation": "Solomon requested an understanding heart to govern God's people.",
    "points": 22
  },
  {
    "id": "a-x11",
    "difficulty": "advanced",
    "episode": 5,
    "type": "trivia",
    "question": "Which prophet married Gomer as part of a prophetic sign?",
    "answer": "Hosea",
    "options": [
      "Hosea",
      "Amos",
      "Joel",
      "Malachi"
    ],
    "scripture": {
      "reference": "Hosea 1:2–3",
      "hint": "His family life became a picture of Israel's unfaithfulness."
    },
    "explanation": "Hosea's marriage symbolized God's relationship with unfaithful Israel.",
    "points": 22
  },
  {
    "id": "a-x12",
    "difficulty": "advanced",
    "episode": 6,
    "type": "scripture",
    "question": "On which island did John receive the Revelation?",
    "answer": "Patmos",
    "options": [
      "Patmos",
      "Crete",
      "Cyprus",
      "Malta"
    ],
    "scripture": {
      "reference": "Revelation 1:9",
      "hint": "John says he was on this island because of God's word."
    },
    "explanation": "John received the Revelation while on Patmos.",
    "points": 22
  },
  {
    "id": "m-x13",
    "difficulty": "master",
    "episode": 1,
    "type": "trivia",
    "question": "Which genealogy in Genesis traces a line from Adam through Seth?",
    "answer": "Genesis 5",
    "options": [
      "Genesis 5",
      "Genesis 10",
      "Exodus 1",
      "Ruth 4"
    ],
    "scripture": {
      "reference": "Genesis 5",
      "hint": "It begins with Adam and records successive generations."
    },
    "explanation": "Genesis 5 traces the line from Adam through Seth.",
    "points": 30
  },
  {
    "id": "m-x14",
    "difficulty": "master",
    "episode": 2,
    "type": "trivia",
    "question": "Which tribe did Joseph's sons Ephraim and Manasseh represent in Israel's inheritance?",
    "answer": "Joseph",
    "options": [
      "Joseph",
      "Judah",
      "Levi",
      "Benjamin"
    ],
    "scripture": {
      "reference": "Genesis 48; Joshua 16–17",
      "hint": "Jacob adopted Joseph's two sons as his own."
    },
    "explanation": "Ephraim and Manasseh received tribal inheritances connected to Joseph.",
    "points": 30
  },
  {
    "id": "m-x15",
    "difficulty": "master",
    "episode": 3,
    "type": "scripture",
    "question": "What covenant sign was given to Abraham in Genesis 17?",
    "answer": "Circumcision",
    "options": [
      "Circumcision",
      "Sabbath",
      "Rainbow",
      "Passover"
    ],
    "scripture": {
      "reference": "Genesis 17:9–14",
      "hint": "It was applied to males in Abraham's household."
    },
    "explanation": "Circumcision was the sign of the covenant with Abraham.",
    "points": 30
  },
  {
    "id": "m-x16",
    "difficulty": "master",
    "episode": 4,
    "type": "trivia",
    "question": "Which prophet confronted King David after his sin with Bathsheba?",
    "answer": "Nathan",
    "options": [
      "Nathan",
      "Gad",
      "Samuel",
      "Elijah"
    ],
    "scripture": {
      "reference": "2 Samuel 12:1–7",
      "hint": "He told the king a story about a rich man and a poor man's lamb."
    },
    "explanation": "Nathan confronted David through a prophetic parable.",
    "points": 30
  },
  {
    "id": "m-x17",
    "difficulty": "master",
    "episode": 5,
    "type": "scripture",
    "question": "Which prophet wrote that the righteous shall live by faith?",
    "answer": "Habakkuk",
    "options": [
      "Habakkuk",
      "Haggai",
      "Zechariah",
      "Malachi"
    ],
    "scripture": {
      "reference": "Habakkuk 2:4",
      "hint": "Paul later quotes this statement in Romans."
    },
    "explanation": "Habakkuk 2:4 contains the famous faith statement.",
    "points": 30
  },
  {
    "id": "m-x18",
    "difficulty": "master",
    "episode": 6,
    "type": "trivia",
    "question": "Which church was described as lukewarm in Revelation?",
    "answer": "Laodicea",
    "options": [
      "Laodicea",
      "Ephesus",
      "Smyrna",
      "Philadelphia"
    ],
    "scripture": {
      "reference": "Revelation 3:14–22",
      "hint": "Jesus said He would spit it out because it was neither hot nor cold."
    },
    "explanation": "Laodicea was rebuked for being lukewarm.",
    "points": 30
  }
];
