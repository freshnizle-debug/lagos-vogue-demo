export const DIFFICULTIES = [
  { id: "beginner", name: "Beginner", subtitle: "Start the Journey", color: "green", unlockAfter: null },
  { id: "intermediate", name: "Intermediate", subtitle: "Go Deeper", color: "blue", unlockAfter: "beginner" },
  { id: "advanced", name: "Advanced", subtitle: "Test Your Knowledge", color: "purple", unlockAfter: "intermediate" },
  { id: "master", name: "Master", subtitle: "Become a Bible Quest Champion", color: "gold", unlockAfter: "advanced" }
];

export const EPISODES = [
  { id: 1, title: "In the Beginning", range: "Genesis 1–25", icon: "🌍", description: "Creation, the Fall, the Flood and the patriarchs." },
  { id: 2, title: "The Promise", range: "Genesis 26–50", icon: "🔥", description: "Isaac, Jacob, Joseph and God's covenant faithfulness." },
  { id: 3, title: "Freedom & Covenant", range: "Exodus–Deuteronomy", icon: "🪔", description: "Moses, the Exodus, the Law and the wilderness journey." },
  { id: 4, title: "Kings & Kingdoms", range: "Joshua–2 Chronicles", icon: "👑", description: "Conquest, judges, kings, David, Solomon and the divided kingdom." },
  { id: 5, title: "Prophets & Return", range: "Ezra–Malachi", icon: "📜", description: "Exile, prophetic warnings, hope and restoration." },
  { id: 6, title: "Christ & the Church", range: "Matthew–Revelation", icon: "✝️", description: "Jesus, the Gospel, Acts, the letters and the hope of Revelation." }
];

export const QUESTION_TYPES = {
  trivia: "Bible Trivia",
  scripture: "Scripture Challenge",
  who: "Who Am I?",
  scramble: "Word Scramble",
  detective: "Scripture Detective"
};

export const SESSION_LENGTH = 10;
export const MAX_QUESTIONS_PER_EPISODE = 400;
export const STARTING_HEARTS = 3;
export const HINT_COST = 10;
export const DAILY_TARGET = 5;
